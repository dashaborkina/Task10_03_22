using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Боркина_10._03._22
{
    public class clsPortal
    {
        Random rand = new Random();

        public string GetStudNumber(Student student)
        {
            string[] names = student.fio.Split(" ");
            return $"{student.year.ToString()}." +
                $"{student.group.ToString()}." +
                $"{names[0][0]}{names[1][0]}{names[2][0]}";
        }

        public double MinAVG(string[] marks)
        {
            double summa = 0;
            foreach (string a in marks)
            {
                summa += int.Parse(a);
            }
            double b = summa / marks.Length;
            return b;
        }

        public List<Mark> GetMarks(DateTime now, List<Student> students)
        {
            List<Mark> ListMarks = new List<Mark>();
            string[] marks = { "П", "Н", "Б", "2", "3", "4", "5", " " };

            int date = 0;
            foreach (Student student in students)
            {
                for (int i = 0; i < 10; i++)
                {
                    Mark a = new Mark(now.AddDays(date), marks[rand.Next(8)], student);
                    date++;
                    ListMarks.Add(a);

                }
            }
            return ListMarks;
        }

        public int[] GetCountDisease(List<Mark> marks)
        {
            Dictionary<int, int> d = new Dictionary<int, int>();
            var b = (from m in marks
                     group m by m.date.Month into g
                     select new { date = g.Key }).ToList();
            foreach (var t in b)
            {
                int pr = marks.FindAll(m => m.date.Month == t.date && m.estimation == "Н").Count;
                d.Add(t.date, pr);
            }
            return d.Select(x => x.Value).ToArray();
        }

        public int[] GetCountTruancy(List<Mark> marks)
        {
            Dictionary<int, int> d = new Dictionary<int, int>();
            var b = (from m in marks
                     group m by m.date.Month into g
                     select new { date = g.Key }).ToList();
            foreach (var t in b)
            {
                int pr = marks.FindAll(m => m.date.Month == t.date && m.estimation == "Б").Count;
                d.Add(t.date, pr);
            }
            return d.Select(x => x.Value).ToArray();
        }

    }
    public class Student
    {
        public int year { get; set; }
        public int group { get; set; }
        public string fio { get; set; }
        public Student(int y, int g, string Fio)
        {
            year = y;
            group = g;
            fio = Fio;
        }

    }
    public class Mark
    {
        public DateTime date { get; set; }
        public string estimation { get; set; }
        public Student student { get; set; }
        public Mark(DateTime d, string estm, Student st)
        {
            date = d;
            estimation = estm;
            student = st;
        }
    }
}
