﻿using Боркина_10._03._22;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Borkina_10._03._22
{
    class Program
    {
        public static clsPortal cls = new clsPortal();
        static void Main(string[] args)

        {
            Console.WriteLine("Студенты");
            List<Mark> marks = new List<Mark>();
            List<Student> students = new List<Student>
            {
                new Student(2012,1,"Мордвинова Дарья Максимовна"),
                new Student(2012,1,"Боркина Дарья Александровна"),
                new Student(2012,2,"Баринов Артём Михайлович"),
                new Student(2011,3,"Барулева Марина Александровна")                
            };
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.03.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("02.04.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("03.05.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("04.06.2022"), students));

            foreach (Mark m in marks)
            {
                Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.estimation} - {m.student.fio}");
            }
            Console.WriteLine();
            // Номер студ.бил
            Console.WriteLine("Студенческий билет");
            foreach (Student st in students)
            {
                Console.WriteLine(cls.GetStudNumber(st));
            }
            Console.WriteLine();
            //Вывод прогулов за месяцы
            Console.WriteLine("Прогулы за месяцы");            
            foreach (int i in cls.GetCountTruancy(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            //Вывод болезней за месяц
            Console.WriteLine("Болезни за месяцы");
            foreach (int i in cls.GetCountDisease(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            
            Console.WriteLine("Средняя оценка");
            Console.WriteLine(cls.MinAVG(new string[4] { "4", "5", "4", "3" }));
            Console.ReadKey();
        }
    }
}

